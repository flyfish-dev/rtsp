#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
LOG="$(mktemp)"
TITLE="RTSP Installer"
EXT_DIR="$HOME/.local/share/rtsp-web-player/extension"
LOCALE_TEXT="$(locale 2>/dev/null || true) $(printenv LANG 2>/dev/null || true) $(printenv LANGUAGE 2>/dev/null || true)"

if case "$LOCALE_TEXT" in *zh*|*Chinese*) true ;; *) false ;; esac; then
  QUESTION="安装 RTSP Runtime 并打开 Chrome 扩展页？"
  COMPLETE="安装完成。\n\n请在 Chrome 扩展页开启 Developer mode，点击 Load unpacked，并选择：\n$EXT_DIR"
else
  QUESTION="Install RTSP Runtime and open Chrome extensions?"
  COMPLETE="Installation complete.\n\nIn Chrome extensions, enable Developer mode, click Load unpacked, and choose:\n$EXT_DIR"
fi

run_install() {
  (cd "$ROOT" && ./install.sh) >"$LOG" 2>&1
}

if command -v zenity >/dev/null 2>&1; then
  zenity --question --title="$TITLE" --width=420 --text="$QUESTION"
  if run_install; then
    zenity --info --title="$TITLE" --width=520 --text="$COMPLETE"
  else
    zenity --error --title="$TITLE" --width=520 --text="$(cat "$LOG")"
    exit 1
  fi
elif command -v kdialog >/dev/null 2>&1; then
  kdialog --title "$TITLE" --yesno "$QUESTION"
  if run_install; then
    kdialog --title "$TITLE" --msgbox "$COMPLETE"
  else
    kdialog --title "$TITLE" --error "$(cat "$LOG")"
    exit 1
  fi
else
  run_install
fi
rm -f "$LOG"
