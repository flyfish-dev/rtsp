Open RTSP Installer.desktop or run ./install-gui.sh.
If your desktop blocks launcher files, run ./install.sh as a fallback.

Fixed extension ID:
giegomfhcmgebjhdiihnjohoinkbcjbh
