#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$HOME/.local/share/rtsp-web-player"
EXT_DIR="$APP_DIR/extension"
BIN="$APP_DIR/rtsp-web-native"
HOST_NAME="com.rtspweb.player"
EXT_ID="giegomfhcmgebjhdiihnjohoinkbcjbh"

mkdir -p "$APP_DIR"
rm -rf "$EXT_DIR"
cp -R "$ROOT/extension" "$EXT_DIR"
pkill -f 'rtsp-web-native.*--gateway' 2>/dev/null || true

ARCH="$(uname -m)"
case "$ARCH" in
  x86_64|amd64) SRC_BIN="$ROOT/native/rtsp-web-native-linux-amd64" ;;
  aarch64|arm64) SRC_BIN="$ROOT/native/rtsp-web-native-linux-arm64" ;;
  *) echo "Unsupported Linux architecture: $ARCH" >&2; exit 1 ;;
esac
cp "$SRC_BIN" "$BIN"
chmod 755 "$BIN"

if command -v wl-copy >/dev/null 2>&1; then
  printf "%s" "$EXT_DIR" | wl-copy
elif command -v xclip >/dev/null 2>&1; then
  printf "%s" "$EXT_DIR" | xclip -selection clipboard
elif command -v xsel >/dev/null 2>&1; then
  printf "%s" "$EXT_DIR" | xsel --clipboard --input
fi

write_manifest() {
  local dir="$1"
  mkdir -p "$dir"
  cat > "$dir/$HOST_NAME.json" <<EOF2
{
  "name": "$HOST_NAME",
  "description": "RTSP Web Player Go Native Host",
  "path": "$BIN",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$EXT_ID/"
  ]
}
EOF2
}

write_manifest "$HOME/.config/google-chrome/NativeMessagingHosts"
write_manifest "$HOME/.config/chromium/NativeMessagingHosts"
write_manifest "$HOME/.config/microsoft-edge/NativeMessagingHosts"

echo "RTSP Native Runtime installed."
echo "Extension directory copied/prepared at:"
echo "$EXT_DIR"
echo
echo "Fixed Chrome extension ID:"
echo "$EXT_ID"
echo
echo "Chrome will open now if available."
echo "Enable Developer mode, click Load unpacked, and select the extension directory above."
if command -v google-chrome >/dev/null 2>&1; then
  google-chrome "chrome://extensions" >/dev/null 2>&1 &
elif command -v google-chrome-stable >/dev/null 2>&1; then
  google-chrome-stable "chrome://extensions" >/dev/null 2>&1 &
elif command -v chromium >/dev/null 2>&1; then
  chromium "chrome://extensions" >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "chrome://extensions" >/dev/null 2>&1 &
fi
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "https://rtsp.flyfish.dev/#demo" >/dev/null 2>&1 &
fi
echo "Done."
