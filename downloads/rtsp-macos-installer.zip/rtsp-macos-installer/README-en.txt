RTSP macOS installer

Use RTSP Installer.app.

Install flow:
1. Double-click RTSP Installer.app.
2. After installation, enable Developer mode in Chrome extensions.
3. Click Load unpacked and choose the extension folder opened by the installer.
4. Return to the online demo and recheck.

Fixed extension ID:
giegomfhcmgebjhdiihnjohoinkbcjbh

If the system cannot verify the developer, right-click RTSP Installer.app and choose Open.
