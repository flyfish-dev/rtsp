RTSP macOS 安装器

推荐使用 RTSP Installer.app。

安装流程：
1. 双击 RTSP Installer.app。
2. 安装完成后，在 Chrome 扩展页开启 Developer mode。
3. 点击 Load unpacked，选择安装器打开的 extension 目录。
4. 回到在线 Demo，点击重新检测。

固定扩展 ID：
giegomfhcmgebjhdiihnjohoinkbcjbh

如果系统提示无法验证开发者，请右键 RTSP Installer.app，选择打开。
