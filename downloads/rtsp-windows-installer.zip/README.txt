Open RTSP Installer.hta.
If Windows blocks HTA files, run install.bat as a fallback.

Fixed extension ID:
giegomfhcmgebjhdiihnjohoinkbcjbh
