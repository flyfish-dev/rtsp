import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
} from "react";
import { configureRTSP, defineRTSPPlayer, updateRTSPPlayer } from "./web.js";

export const RtspPlayer = forwardRef(function RtspPlayer(props, ref) {
  const {
    extensionId,
    url,
    src,
    width = 640,
    height = 360,
    autoplay = false,
    controls = true,
    muted = false,
    transport = "auto",
    rtspTransport = "tcp",
    mediaTransport,
    codec = "auto",
    runtime = "extension",
    tagName = "rtsp-player",
    className,
    style,
    onReady,
    onError,
    onStarting,
    ...rest
  } = props;
  const innerRef = useRef(null);

  useEffect(() => {
    configureRTSP({ extensionId, tagName, runtime });
    defineRTSPPlayer(tagName);
  }, [extensionId, tagName, runtime]);

  useImperativeHandle(ref, () => innerRef.current, []);

  useEffect(() => {
    if (!innerRef.current) return;
    updateRTSPPlayer(innerRef.current, {
      extensionId,
      url,
      src,
      width,
      height,
      autoplay,
      controls,
      muted,
      transport,
      rtspTransport,
      mediaTransport,
      codec,
      runtime,
    });
  }, [extensionId, url, src, width, height, autoplay, controls, muted, transport, rtspTransport, mediaTransport, codec, runtime]);

  useEffect(() => {
    const el = innerRef.current;
    if (!el) return undefined;
    const listeners = [
      ["ready", onReady],
      ["error", onError],
      ["starting", onStarting],
    ];
    for (const [type, handler] of listeners) {
      if (handler) el.addEventListener(type, handler);
    }
    return () => {
      for (const [type, handler] of listeners) {
        if (handler) el.removeEventListener(type, handler);
      }
    };
  }, [onReady, onError, onStarting]);

  return React.createElement(tagName, {
    ...rest,
    ref: innerRef,
    className,
    style,
  });
});

export default RtspPlayer;
