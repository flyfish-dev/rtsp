import {
  defineComponent,
  h,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
} from "vue";
import { configureRTSP, defineRTSPPlayer, updateRTSPPlayer } from "./web.js";

export const RtspPlayer = defineComponent({
  name: "RtspPlayer",
  props: {
    extensionId: String,
    url: String,
    src: String,
    width: { type: [String, Number], default: 640 },
    height: { type: [String, Number], default: 360 },
    autoplay: { type: Boolean, default: false },
    controls: { type: Boolean, default: true },
    muted: { type: Boolean, default: false },
    transport: { type: String, default: "auto" },
    rtspTransport: { type: String, default: "tcp" },
    mediaTransport: String,
    codec: { type: String, default: "auto" },
    runtime: { type: String, default: "extension" },
    tagName: { type: String, default: "rtsp-player" },
  },
  emits: ["ready", "error", "starting"],
  setup(props, { emit, attrs }) {
    const el = ref(null);

    const sync = () => {
      if (!el.value) return;
      configureRTSP({ extensionId: props.extensionId, tagName: props.tagName, runtime: props.runtime });
      defineRTSPPlayer(props.tagName);
      updateRTSPPlayer(el.value, props);
    };

    const onReady = (event) => emit("ready", event);
    const onError = (event) => emit("error", event);
    const onStarting = (event) => emit("starting", event);

    onMounted(() => {
      sync();
      el.value?.addEventListener("ready", onReady);
      el.value?.addEventListener("error", onError);
      el.value?.addEventListener("starting", onStarting);
    });

    onBeforeUnmount(() => {
      el.value?.removeEventListener("ready", onReady);
      el.value?.removeEventListener("error", onError);
      el.value?.removeEventListener("starting", onStarting);
    });

    watch(() => ({ ...props }), sync, { deep: true });

    return () => h(props.tagName, {
      ...attrs,
      ref: el,
    });
  },
});

export default RtspPlayer;
